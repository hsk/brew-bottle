/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-gcc-10-arm-20210220/configure --target=m68k-elf --prefix=/private/tmp/gendev-0.4.0-20210422-9681-quzcgk/gendev-0.4.0-0.4.0f/toolchain/../build --without-headers --with-newlib --enable-languages=c --disable-libssp --disable-tls --with-cpu=m68000 --disable-werror --disable-nls --disable-multilib --disable-libquadmath : (reconfigured) ../gcc-gcc-10-arm-20210220/configure --target=m68k-elf --prefix=/private/tmp/gendev-0.4.0-20210422-9681-quzcgk/gendev-0.4.0-0.4.0f/toolchain/../build --with-newlib --disable-libssp --disable-tls --enable-threads=single --enable-languages=c --with-cpu=m68000 --disable-werror --disable-nls --disable-multilib --disable-libquadmath";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "m68000" } };
